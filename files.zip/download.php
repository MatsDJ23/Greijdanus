<?php
/**
 * FileDrop - Download Handler
 * GET /download.php?code=XXXXXXXX  → serve the file
 * GET /download.php?code=XXXXXXXX&info=1 → return JSON metadata
 */

define('UPLOAD_DIR', __DIR__ . '/files/');

header('Access-Control-Allow-Origin: *');

$code = preg_replace('/[^A-Z0-9]/', '', strtoupper(trim($_GET['code'] ?? '')));
$info = isset($_GET['info']);

if (strlen($code) === 0) {
    http_response_code(400);
    echo json_encode(['ok' => false, 'error' => 'No code provided.']);
    exit;
}

$meta_path = UPLOAD_DIR . $code . '.json';

if (!file_exists($meta_path)) {
    http_response_code(404);
    if ($info) {
        header('Content-Type: application/json');
        echo json_encode(['ok' => false, 'error' => 'Code not found or expired.']);
    } else {
        http_response_code(404);
        header('Content-Type: text/plain');
        echo "File not found or expired.\n";
    }
    exit;
}

$meta = json_decode(file_get_contents($meta_path), true);

// Check expiry
if (time() > $meta['expires']) {
    @unlink(UPLOAD_DIR . $meta['stored']);
    @unlink($meta_path);
    http_response_code(410);
    if ($info) {
        header('Content-Type: application/json');
        echo json_encode(['ok' => false, 'error' => 'File has expired.']);
    } else {
        header('Content-Type: text/plain');
        echo "File has expired.\n";
    }
    exit;
}

$file_path = UPLOAD_DIR . $meta['stored'];

if (!file_exists($file_path)) {
    http_response_code(404);
    echo "File missing on disk.\n";
    exit;
}

if ($info) {
    header('Content-Type: application/json');
    echo json_encode([
        'ok'         => true,
        'code'       => $meta['code'],
        'filename'   => $meta['filename'],
        'size'       => $meta['size'],
        'expires_in' => max(0, $meta['expires'] - time()),
    ]);
    exit;
}

// Serve file
$mime = mime_content_type($file_path) ?: 'application/octet-stream';
header('Content-Type: ' . $mime);
header('Content-Disposition: attachment; filename="' . addslashes($meta['filename']) . '"');
header('Content-Length: ' . filesize($file_path));
header('Cache-Control: no-store');

// Stream in chunks (handles large files without memory issues)
$fp = fopen($file_path, 'rb');
while (!feof($fp)) {
    echo fread($fp, 65536);
    flush();
}
fclose($fp);

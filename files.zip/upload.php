<?php
/**
 * FileDrop - Upload Handler
 * Accepts multipart/form-data (web) or raw POST (curl)
 * Returns JSON for web, plain text code for CLI
 */

define('UPLOAD_DIR', __DIR__ . '/files/');
define('MAX_SIZE',   4 * 1024 * 1024 * 1024); // 4 GB
define('TTL',        5 * 60);                  // 5 minutes in seconds
define('CODE_LEN',   8);

header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, X-Filename');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { http_response_code(204); exit; }
if ($_SERVER['REQUEST_METHOD'] !== 'POST')    { http_response_code(405); exit; }

// Clean up expired files on every request (lightweight, fine for personal use)
cleanup_expired();

// Detect CLI vs browser (curl without -H "Accept: application/json" is treated as CLI)
$want_json = (
    isset($_SERVER['HTTP_ACCEPT']) &&
    strpos($_SERVER['HTTP_ACCEPT'], 'application/json') !== false
);

// ---------- Receive the file ----------
$tmpfile  = null;
$filename = 'upload';
$size     = 0;

if (!empty($_FILES['file'])) {
    // Standard multipart upload (web form or curl -F)
    $f = $_FILES['file'];
    if ($f['error'] !== UPLOAD_ERR_OK) {
        respond_error('Upload error: ' . upload_error_msg($f['error']), $want_json);
    }
    $tmpfile  = $f['tmp_name'];
    $filename = basename($f['name']);
    $size     = $f['size'];
} else {
    // Raw body upload (curl --data-binary / --upload-file)
    $raw = fopen('php://input', 'rb');
    if (!$raw) respond_error('Could not read input.', $want_json);

    $tmp = tempnam(sys_get_temp_dir(), 'fdrop_');
    $out = fopen($tmp, 'wb');
    $size = 0;
    while (!feof($raw)) {
        $chunk = fread($raw, 65536);
        $size += strlen($chunk);
        if ($size > MAX_SIZE) {
            fclose($raw); fclose($out); unlink($tmp);
            respond_error('File exceeds 4 GB limit.', $want_json);
        }
        fwrite($out, $chunk);
    }
    fclose($raw); fclose($out);

    if ($size === 0) { unlink($tmp); respond_error('Empty upload.', $want_json); }

    $tmpfile  = $tmp;
    // Filename can be passed via header: -H "X-Filename: myfile.tar.gz"
    $filename = isset($_SERVER['HTTP_X_FILENAME'])
        ? basename($_SERVER['HTTP_X_FILENAME'])
        : 'upload.bin';
}

if ($size > MAX_SIZE) respond_error('File exceeds 4 GB limit.', $want_json);

// ---------- Generate code & store ----------
if (!is_dir(UPLOAD_DIR)) mkdir(UPLOAD_DIR, 0750, true);

$code    = generate_code();
$ext     = pathinfo($filename, PATHINFO_EXTENSION);
$stored  = $code . ($ext ? '.' . $ext : '');
$meta    = UPLOAD_DIR . $code . '.json';
$dest    = UPLOAD_DIR . $stored;

if (!move_uploaded_file_safe($tmpfile, $dest)) {
    respond_error('Could not store file.', $want_json);
}

file_put_contents($meta, json_encode([
    'code'     => $code,
    'filename' => $filename,
    'stored'   => $stored,
    'size'     => $size,
    'expires'  => time() + TTL,
]));

// ---------- Respond ----------
$base = (isset($_SERVER['HTTPS']) ? 'https' : 'http')
      . '://' . $_SERVER['HTTP_HOST']
      . rtrim(dirname($_SERVER['SCRIPT_NAME']), '/');

if ($want_json) {
    header('Content-Type: application/json');
    echo json_encode([
        'ok'      => true,
        'code'    => $code,
        'expires' => TTL,
        'download'=> $base . '/download.php?code=' . $code,
    ]);
} else {
    header('Content-Type: text/plain');
    echo $code . "\n";
}


// ===== Helpers =====

function generate_code(): string {
    $chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'; // no confusable chars
    $code  = '';
    for ($i = 0; $i < CODE_LEN; $i++) {
        $code .= $chars[random_int(0, strlen($chars) - 1)];
    }
    return $code;
}

function cleanup_expired(): void {
    $dir = UPLOAD_DIR;
    if (!is_dir($dir)) return;
    foreach (glob($dir . '*.json') as $meta) {
        $data = json_decode(file_get_contents($meta), true);
        if (!$data || time() > $data['expires']) {
            @unlink($dir . $data['stored']);
            @unlink($meta);
        }
    }
}

function move_uploaded_file_safe(string $tmp, string $dest): bool {
    if (is_uploaded_file($tmp)) {
        return move_uploaded_file($tmp, $dest);
    }
    // raw body path
    return rename($tmp, $dest);
}

function respond_error(string $msg, bool $json): never {
    http_response_code(400);
    if ($json) {
        header('Content-Type: application/json');
        echo json_encode(['ok' => false, 'error' => $msg]);
    } else {
        header('Content-Type: text/plain');
        echo 'ERROR: ' . $msg . "\n";
    }
    exit;
}

function upload_error_msg(int $code): string {
    return match($code) {
        UPLOAD_ERR_INI_SIZE, UPLOAD_ERR_FORM_SIZE => 'File too large.',
        UPLOAD_ERR_PARTIAL   => 'Partial upload.',
        UPLOAD_ERR_NO_FILE   => 'No file sent.',
        UPLOAD_ERR_NO_TMP_DIR=> 'No temp directory.',
        UPLOAD_ERR_CANT_WRITE=> 'Cannot write to disk.',
        default              => "Code $code.",
    };
}

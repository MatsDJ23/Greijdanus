# FileDrop

Self-hosted ephemeral file sharing. Upload a file, get an 8-character code.
Anyone with the code can download the file within 5 minutes. Files are then deleted automatically.

Max file size: **4 GB** · TTL: **5 minutes**

---

## Files

| File | Purpose |
|---|---|
| `index.html` | Web UI (upload + download by code) |
| `upload.php` | Upload endpoint (web form + curl) |
| `download.php` | Download endpoint |
| `nginx.conf` | nginx + PHP-FPM config snippet |

---

## Setup

### 1. Copy files to your web root

```bash
cp index.html upload.php download.php /var/www/filedrop/
mkdir -p /var/www/filedrop/files
chmod 750 /var/www/filedrop/files
chown www-data:www-data /var/www/filedrop/files
```

### 2. Configure nginx

Paste the contents of `nginx.conf` into your server block (or use it as a new block), then:

```bash
nginx -t && systemctl reload nginx
```

### 3. Configure PHP

Add to `/etc/php/8.X/fpm/conf.d/99-filedrop.ini`:

```ini
upload_max_filesize = 4096M
post_max_size       = 4096M
max_execution_time  = 600
max_input_time      = 600
memory_limit        = 256M
```

Then restart PHP-FPM:

```bash
systemctl restart php8.2-fpm   # adjust version
```

---

## CLI Usage

### Upload (multipart, returns the code as plain text)

```bash
curl -X POST https://your-domain.com/upload.php \
  -F "file=@/path/to/file.zip"
```

### Upload (raw stream, useful for pipes)

```bash
curl -X POST https://your-domain.com/upload.php \
  -H "X-Filename: backup.tar.gz" \
  --data-binary @/path/to/backup.tar.gz
```

### Upload in a script and capture the code

```bash
CODE=$(curl -sX POST https://your-domain.com/upload.php -F "file=@archive.zip")
echo "Code: $CODE"
```

### Get JSON response (add Accept header)

```bash
curl -sX POST https://your-domain.com/upload.php \
  -H "Accept: application/json" \
  -F "file=@file.txt"
# → {"ok":true,"code":"AB3KXYZ9","expires":300,"download":"https://..."}
```

### Download by code

```bash
curl -O -J "https://your-domain.com/download.php?code=AB3KXYZ9"
# or with explicit output name:
curl -o myfile.zip "https://your-domain.com/download.php?code=AB3KXYZ9"
```

### Check file info (JSON)

```bash
curl "https://your-domain.com/download.php?code=AB3KXYZ9&info=1"
# → {"ok":true,"code":"...","filename":"...","size":12345,"expires_in":243}
```

---

## How it works

- Files are stored in `files/` with the code as the filename prefix
- A `.json` sidecar stores metadata (original filename, size, expiry timestamp)
- On every upload request, PHP scans `files/*.json` and deletes expired entries
- No database needed — pure filesystem

---

## Security notes

- The `files/` directory is blocked from direct web access via nginx (`deny all`)
- Codes use a 32-character alphabet (no O/0/I/1 confusion), 8 chars = ~1 trillion combinations
- No user accounts, no logs, no tracking
- Consider adding HTTPS (Let's Encrypt / certbot) if not already in place
